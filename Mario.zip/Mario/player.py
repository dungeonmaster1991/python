import pygame
import pyganim
import platform

MOVE_SPEED = 7
WIDTH = 28
HEIGHT = 45
COLOR = "#000000"
JUMP_POWER = 10
GRAVITY = 0.35

ANIMATION_DELAY = 1  # скорость смены кадров
ANIMATION_RIGHT = ['textures/r1.png',
                   'textures/r2.png',
                   'textures/r3.png',
                   'textures/r4.png',
                   'textures/r5.png']
ANIMATION_LEFT = ['textures/l1.png',
                  'textures/l2.png',
                  'textures/l3.png',
                  'textures/l4.png',
                  'textures/l5.png']
ANIMATION_JUMP_LEFT = [('textures/jl.png',
                        ANIMATION_DELAY)]
ANIMATION_JUMP_RIGHT = [('textures/jr.png',
	                    ANIMATION_DELAY)]
ANIMATION_JUMP = [('textures/j.png',
	                    ANIMATION_DELAY)]
ANIMATION_STAY = [('textures/0.png',
	                    ANIMATION_DELAY)]

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.xvel = 0
        self.yvel = 0
        self.startX = x
        self.startY = y
        self.image = pygame.Surface((WIDTH, HEIGHT))
        self.image.fill(pygame.Color(COLOR))
        self.rect = pygame.Rect(x, y, WIDTH, HEIGHT)
        self.left = False
        self.right = False
        self.up = False
        self.onGround = False

        self.image.set_colorkey(pygame.Color(COLOR))
        #  Анимация движения вправо
        bolt_anim = []
        for anim in ANIMATION_RIGHT:
            bolt_anim.append((anim, ANIMATION_DELAY))
        self.boltAnimRight = pyganim.PygAnimation(bolt_anim)
        self.boltAnimRight.play()
        #  Анимация движения влево
        bolt_anim = []
        for anim in ANIMATION_LEFT:
            bolt_anim.append((anim, ANIMATION_DELAY))
        self.boltAnimLeft = pyganim.PygAnimation(bolt_anim)
        self.boltAnimLeft.play()

        self.boltAnimStay = pyganim.PygAnimation(ANIMATION_STAY)
        self.boltAnimStay.play()
        # По-умолчанию, стоим
        self.boltAnimStay.blit(self.image, (0, 0))
        self.boltAnimJumpLeft = pyganim.PygAnimation(ANIMATION_JUMP_LEFT)
        self.boltAnimJumpLeft.play()
        self.boltAnimJumpRight = pyganim.PygAnimation(ANIMATION_JUMP_RIGHT)
        self.boltAnimJumpRight.play()
        self.boltAnimJump = pyganim.PygAnimation(ANIMATION_JUMP)
        self.boltAnimJump.play()

    def update(self, platforms):
        if self.left:
            self.xvel = -MOVE_SPEED  # Лево = x- n
            self.image.fill(pygame.Color(COLOR))
            self.boltAnimLeft.blit(self.image, (0, 0))

        if self.right:
            self.xvel = MOVE_SPEED  # Право = x + n
            self.image.fill(pygame.Color(COLOR))
            self.boltAnimRight.blit(self.image, (0, 0))


        if not (self.left or self.right):
            self.xvel = 0
            if not self.up:
                self.image.fill(pygame.Color(COLOR))
            self.boltAnimStay.blit(self.image, (0, 0))

        if self.up:
            if self.onGround:
                self.yvel = -JUMP_POWER
            self.image.fill(pygame.Color(COLOR))
            if self.left:
                self.boltAnimJumpLeft.blit(self.image, (0, 0))
            elif self.right:
                self.boltAnimJumpRight.blit(self.image, (0, 0))
            else:
                self.boltAnimJump.blit(self.image, (0, 0))

        if not self.onGround:
            self.yvel += GRAVITY

        self.onGround = False

        self.rect.y += self.yvel
        self.collide(0, self.yvel, platforms)

        self.rect.x += self.xvel
        self.collide(self.xvel, 0, platforms)

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))

    def collide(self, xvel, yvel, platforms):
        for p in platforms:
            if pygame.sprite.collide_rect(self, p):

                if isinstance(p, platform.BlockDie):
                    self.die()

                if xvel > 0:
                    self.rect.right = p.rect.left

                if xvel < 0:
                    self.rect.left = p.rect.right

                if yvel > 0:
                    self.rect.bottom = p.rect.top
                    self.onGround = True
                    self.yvel = 0

                if yvel < 0:
                    self.rect.top = p.rect.bottom
                    self.yvel = 0

    def move(self, event):
        if event.type == pygame.KEYDOWN and \
                event.key == pygame.K_a:
            self.left = True
        if event.type == pygame.KEYDOWN and \
                event.key == pygame.K_d:
            self.right = True

        if event.type == pygame.KEYUP and \
                event.key == pygame.K_d:
            self.right = False
        if event.type == pygame.KEYUP and \
                event.key == pygame.K_a:
            self.left = False

        if event.type == pygame.KEYDOWN and \
                event.key == pygame.K_SPACE:
            self.up = True
        if event.type == pygame.KEYUP and \
                event.key == pygame.K_SPACE:
            self.up = False

    def die(self):
        pygame.time.wait(500)
        self.teleporting(self.startX, self.startY)


    def teleporting(self, goX, goY):
        self.rect.x = goX
        self.rect.y = goY
