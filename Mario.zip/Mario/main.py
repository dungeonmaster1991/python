import pygame
import level
import player
import camera

W = 800
H = 600

DISPLAY = (W,H)


def main():
    pygame.init()  # Инициация PyGame, обязательная строчка
    # Создаем окошко
    screen = pygame.display.set_mode(DISPLAY)
    # Пишем в шапку
    pygame.display.set_caption("Super Mario Boy")
    # будем использовать как фон
    # Загружаем изображение для фона
    bg = pygame.image.load("OP0IU20.jpg")
    hero = player.Player(55, 55)
    timer = pygame.time.Clock()

    entities = pygame.sprite.Group()  # Все объекты
    level_1 = level.Level()
    # то, во что мы будем врезаться или опираться
    platforms = level_1.getPlatform()
    for platform in platforms:
        entities.add(platform)
    entities.add(hero)

    # Высчитываем фактическую ширину уровня
    total_level_width = len(level_1.load()[0]) * level.platform.PLATFORM_WIDTH

    # Высчитываем фактическую высоту уровня

    total_level_height = len(level_1.load()) * level.platform.PLATFORM_HEIGHT

    main_camera = camera.Camera(total_level_width, total_level_height)

    while True:
        timer.tick(30)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                raise SystemExit(1)
            hero.move(event)
        # Каждую итерацию всё перерисовываем
        screen.blit(bg, (0, 0))
        hero.update(platforms)
        # entities.draw(screen)
        main_camera.update(hero)
        for e in entities:
            screen.blit(e.image, main_camera.apply(e))
        # обновление и вывод всех изменений на экран
        pygame.display.update()


if __name__ == "__main__":
    main()
